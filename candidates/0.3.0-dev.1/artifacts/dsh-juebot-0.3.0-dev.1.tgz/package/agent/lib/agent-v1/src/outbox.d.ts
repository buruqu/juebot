import type { StateStore, Transaction } from './store.ts';
export interface RevisionVector {
    binding: number;
    policy: number;
    memory: number;
    identity: number;
    expression: number;
}
export interface Outgoing {
    id: string;
    account: string;
    conversation: string;
    kind: 'social' | 'repetition' | 'code-result' | 'creation';
    body: string;
    payload: unknown;
    revisions: RevisionVector;
    sourceRefs: {
        id: string;
        revision: number;
    }[];
    createdAt: number;
    dueAt: number;
    expiresAt: number;
    costUnits: number;
}
export interface Delivery extends Outgoing {
    sequence: number;
    status: 'queued' | 'sending' | 'confirmed' | 'failed' | 'unknown' | 'held' | 'cancelled';
    reason: string;
    claim: string | null;
    leaseUntil: number | null;
    receipt: string | null;
    charged: boolean;
    budgetWindow: string | null;
}
export interface BudgetWindow {
    id: string;
    limit: number;
}
export interface SendGate {
    allowed: boolean;
    reason: string;
}
export declare class DurableOutbox {
    private store;
    constructor(store: StateStore);
    list(): Delivery[];
    state(): {
        revision: number;
        paused: boolean;
        pausedAccounts: string[];
    };
    setPause(expectedRevision: number, paused: boolean, accounts?: string[]): void;
    enqueue(input: Outgoing): string;
    /** For creation approval consumption and enqueue to commit in one transaction. */
    enqueueIn(tx: Transaction, input: Outgoing): string;
    claim(account: string, owner: string, now: number, leaseMs: number, budget: BudgetWindow | null, gate: (item: Delivery) => SendGate): Delivery | null;
    finish(id: string, claim: string, now: number, outcome: 'confirmed' | 'failed' | 'unknown', receipt: string | null, accounting?: 'spent' | 'not-submitted'): Delivery;
    /** Trusted operator/platform reconciliation with an external evidence id; never automatically retries unknown. */
    releaseUnsent(id: string, claim: string, now: number, reason: string): Delivery;
    /** Trusted operator/platform reconciliation with an external evidence id; never automatically retries unknown. */
    reconcile(id: string, outcome: 'confirmed' | 'failed', proof: string, accounting?: 'spent' | 'not-submitted'): Delivery;
    private settle;
    cancel(id: string): void;
    recover(): void;
}
